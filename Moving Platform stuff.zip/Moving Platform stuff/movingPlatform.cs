﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movingPlatform : MonoBehaviour
{
    public bool isMovingRight;
    public GameObject leftTarget;
    public GameObject rightTarget;
    public float speed;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (isMovingRight)
        {
            transform.position = Vector3.MoveTowards(transform.position, rightTarget.transform.position, speed*Time.deltaTime);
        }
        else
        {
            transform.position = Vector3.MoveTowards(transform.position, leftTarget.transform.position, speed * Time.deltaTime);
        }
    }
    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.tag == "leftTarget")
        {
            isMovingRight = true; 
        }
        if (col.gameObject.tag == "rightTarget")
        {
            isMovingRight = false;
        }
    }

}
